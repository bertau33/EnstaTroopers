/**
* Classe PortableRandom.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.math;

import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class PortableRandom.
 */
public class PortableRandom extends Random {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new portable random.
	 *
	 * @param seed the seed
	 */
	public PortableRandom(int seed) {
		
	}
}

