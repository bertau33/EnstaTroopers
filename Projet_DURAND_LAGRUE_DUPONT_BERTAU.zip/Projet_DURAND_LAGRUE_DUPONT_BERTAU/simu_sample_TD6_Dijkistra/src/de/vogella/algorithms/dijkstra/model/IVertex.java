package de.vogella.algorithms.dijkstra.model;

public interface IVertex {
  public String getId();

  public String getName();
    
} 