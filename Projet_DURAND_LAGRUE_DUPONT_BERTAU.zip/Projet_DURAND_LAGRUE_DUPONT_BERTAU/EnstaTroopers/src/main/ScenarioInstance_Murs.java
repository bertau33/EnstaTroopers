package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import enstabretagne.base.time.LogicalDateTime;
import enstabretagne.base.time.LogicalDuration;
import enstabretagne.simulation.components.ScenarioId;
import enstabretagne.simulation.core.IScenario;
import enstabretagne.simulation.core.IScenarioInstance;
import application.entities.Robot.RobotFeatures;
import application.entities.Robot.RobotInit;
import application.entities.Wall.WallFeatures;
import application.entities.Wall.WallInit;
import application.scenarios.ScenMvtCollisionAvoidance;
import application.scenarios.ScenMvtCollisionAvoidanceFeatures;
import javafx.geometry.Point3D;
import javafx.scene.paint.Color;

public class ScenarioInstance_Murs implements IScenarioInstance {
	
	@Override
	public IScenario getScenarioInstance(long seed) {
		ScenMvtCollisionAvoidanceFeatures mcaf = new ScenMvtCollisionAvoidanceFeatures("RbScen1");


		// Construction de l'environnement
		int positionx[] = {5,5,5,5,5,5,5,5,5,
							10,10,10,10,10,
							15,15,15,15,
							20,20,20,20,
							25,25,25,25,25,25,25,25,25};
		int positiony[] = {5,10,15,20,25,30,35,40,45,
							5,15,20,25,30,
							5,20,25,30,
							5,10,25,30,
							5,10,15,20,25,30,35,40,45};


        Random rand = new Random();
        int position1 = rand.nextInt( 31) ;
		int position2 = rand.nextInt( 31) ;
		int position3 = rand.nextInt(31);

		while(position2 == position1){
			position2 = rand.nextInt( 31) ;
		}

		while(position3 == position1 || position3 == position2){
			position3 = rand.nextInt( 31) ;
		}

		System.out.println(position1);
		System.out.println(position2);
		System.out.println(position3);

		List<Point3D> lP;
		
		WallFeatures wf = new WallFeatures("RF", Color.ORANGE, 2, 0.2, 2.5);
		WallInit contour_lieux;
		lP = new ArrayList<>();
		lP.add(new Point3D(0, 0, 0));
		lP.add(new Point3D(0, 50, 0));
		lP.add(new Point3D(30, 50, 0));
		lP.add(new Point3D(30, 0, 0));
		lP.add(new Point3D(0, 0, 0));
		contour_lieux = new WallInit("Contours lieux", new Point3D(0, 0, 0), Point3D.ZERO, lP);
		mcaf.getWalls().put(contour_lieux, wf);
		
		WallInit mur_ennemi;
		lP = new ArrayList<>();
		lP.add(new Point3D(10, 45, 0));
		lP.add(new Point3D(10, 35, 0));
		lP.add(new Point3D(20, 35, 0));
		lP.add(new Point3D(20, 45, 0));
		mur_ennemi = new WallInit("Mur ennemie", new Point3D(0, 0, 0), Point3D.ZERO, lP);
		mcaf.getWalls().put(mur_ennemi, wf);
		
		WallInit mur_central;
		lP = new ArrayList<>();
		lP.add(new Point3D(10, 11, 0));
		lP.add(new Point3D(15, 11, 0));
		lP.add(new Point3D(15, 16, 0));
		lP.add(new Point3D(20, 16, 0));
		lP.add(new Point3D(20, 21, 0));
		mur_central = new WallInit("Mur central", new Point3D(0, 0, 0), Point3D.ZERO, lP);
		mcaf.getWalls().put(mur_central, wf);


		WallFeatures gf = new WallFeatures("GF", Color.GREY, 1, 30, 50);
		WallInit sol;
		sol = new WallInit("Sol", new Point3D(15, 0, 0), Point3D.ZERO, new ArrayList<>());
		mcaf.getWalls().put(sol, gf);

		WallFeatures tf = new WallFeatures("TF", Color.BURLYWOOD, 3, 1, 1);
		WallInit table;
		table = new WallInit("Table", new Point3D(positionx[position1], positiony[position1], 0), Point3D.ZERO, new ArrayList<>());
		mcaf.getWalls().put(table, tf);

		WallFeatures cf = new WallFeatures("CF", Color.BURLYWOOD, 3, 0.5, 0.5);
		WallInit chaise;
		chaise = new WallInit("Chaise", new Point3D(positionx[position2], positiony[position2], 0), Point3D.ZERO, new ArrayList<>());
		mcaf.getWalls().put(chaise, cf);

		WallInit chaise2;
		chaise2 = new WallInit("Chaise2", new Point3D(positionx[position3], positiony[position3], 0), Point3D.ZERO, new ArrayList<>());
		mcaf.getWalls().put(chaise2, cf);

		// Cr�ation des robots
		// Cr�ation du robot gentil
		RobotFeatures r2d2f = new RobotFeatures("Reconaissance", 5.0, 100.0, 0.5,600.0,100.0);
		RobotInit r2d2 = new RobotInit("R2D2", Color.AQUA,1, new Point3D(2, 2, 1), new Point3D(0, 0, 0), false,
				new Point3D(10, 2, 0));
		mcaf.getRobots().put(r2d2, r2d2f);

		/*RobotFeatures Terminatorf = new RobotFeatures("Assault", 5.0, 100.0, 0.5,600.0,100.0);
		RobotInit Terminator = new RobotInit("Terminator", Color.DARKOLIVEGREEN,1, new Point3D(-2, -2, 1), new Point3D(0, 0, 0), false,
				new Point3D(10, 2, 0));
		mcaf.getRobots().put(Terminator, Terminatorf);*/

		// Cr�ation du robot m�chant
		RobotFeatures rfbad = new RobotFeatures("RF", 0, 100, 0.5,600.0,100.0);

		RobotInit rb = new RobotInit("Grivious", Color.DARKRED,3, new Point3D(15, 40, 1), new Point3D(0, 0, 90),
				true, Point3D.ZERO);
		mcaf.getRobots().put(rb, rfbad);
		
		// Initialisation du temps
		LogicalDateTime start = new LogicalDateTime("08/01/2020 13:00");
		LogicalDateTime end = start.add(LogicalDuration.ofMinutes(2));

		ScenMvtCollisionAvoidance scen = new ScenMvtCollisionAvoidance(new ScenarioId("Scen1"), mcaf, start, end);
		return scen;


	}

}