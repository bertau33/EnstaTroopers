package application.entities.MouvementSequenceur;

import enstabretagne.base.logger.Logger;
import enstabretagne.simulation.components.IEntity;
import enstabretagne.simulation.components.data.SimFeatures;
import enstabretagne.simulation.core.implementation.SimEvent;
import application.entities.Robot.Robot;
import javafx.geometry.Point3D;

public class EntityMouvementSequenceurExemple extends EntityMouvementSequenceur{

	EntityMouvementSequenceurFeature emsf;
	EntityMouvementSequenceurInit emsi;
	
	public EntityMouvementSequenceurExemple(String name, SimFeatures features) {
		super(name, features);
	}
	
	@Override
	protected void AfterActivate(IEntity sender, boolean starting) {
		// TODO Auto-generated method stub
		super.AfterActivate(sender, starting);

		emsf = (EntityMouvementSequenceurFeature) getFeatures();
		emsi = (EntityMouvementSequenceurInit) getInitParameters();


		selfRotator.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
				mv.getRotationXYZ(getCurrentLogicalDate()), new Point3D(10, 2, 1), emsf.getMaxSelfRotationSpeed());
		mv = selfRotator;


		Post(new Checkmur(), mv.getDurationToReach());
	}

	class Checkmur extends SimEvent {

		@Override
		public void Process() {
			if (emsf.getMaxLinearSpeed() != 0) {
				EntityMouvementSequenceurExemple e= (EntityMouvementSequenceurExemple) Owner();
				Robot r = (Robot) e.getParent();
				selfRotator.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
						mv.getRotationXYZ(getCurrentLogicalDate()), r.getPosition(), emsf.getMaxSelfRotationSpeed());
				mv = selfRotator;

				Logger.Information(r, "AfterActivate", "Can see robot ? "+r.canSeeRobot());
				if(r.canSeeRobot()){Post(new MouvementFinished(), mv.getDurationToReach());}
				else {Post(new Essais(), mv.getDurationToReach());}
			}

		}
	}


	class MouvementFinished extends SimEvent {

		@Override
		public void Process() {

			EntityMouvementSequenceurExemple e= (EntityMouvementSequenceurExemple) Owner();
			Robot r = (Robot) e.getParent();
			Point3D pointdepart = new Point3D(2,2,1);
			Logger.Detail(this, "RectilinearMouvementFinished", "Finished : " + emsi.getTarget());
			selfRotator.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
					mv.getRotationXYZ(getCurrentLogicalDate()), r.getPosition(), emsf.getMaxSelfRotationSpeed());
			mv = selfRotator;


			if(r.getPosition().getX()==pointdepart.getX()&&r.getPosition().getY()==pointdepart.getY()){Post(new RecoFinished(), mv.getDurationToReach());}
			else {Post(new Retour(), mv.getDurationToReach());}
		}

	}

	class RecoFinished extends SimEvent {

		@Override
		public void Process() {

			Logger.Information(this, "AfterActivate", "Recognition done !!!");
			staticMover.init(mv.getPosition(getCurrentLogicalDate()), mv.getRotationXYZ(getCurrentLogicalDate()));
			mv = staticMover;
		}

	}
	class Essais extends SimEvent {

		@Override
		public void Process() {
			EntityMouvementSequenceurExemple e= (EntityMouvementSequenceurExemple) Owner();
			Robot r = (Robot) e.getParent();

			if (emsf.getMaxLinearSpeed() != 0) {

				Point3D nextpoint = r.ping();
				selfRotator.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
						mv.getRotationXYZ(getCurrentLogicalDate()),nextpoint, emsf.getMaxSelfRotationSpeed());
				mv = selfRotator;
				rectilinearMover.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
						nextpoint, emsf.getMaxLinearSpeed());
				mv = rectilinearMover;
				Post(new Checkmur(), mv.getDurationToReach());
			}

		}
	}

	class Retour extends SimEvent {

		@Override
		public void Process() {
			EntityMouvementSequenceurExemple e= (EntityMouvementSequenceurExemple) Owner();
			Robot r = (Robot) e.getParent();

			if (emsf.getMaxLinearSpeed() != 0) {

				Point3D nextpoint = r.dijkstra();
				selfRotator.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
						mv.getRotationXYZ(getCurrentLogicalDate()),nextpoint, emsf.getMaxSelfRotationSpeed());
				mv = selfRotator;
				rectilinearMover.init(getCurrentLogicalDate(), mv.getPosition(getCurrentLogicalDate()),
						nextpoint, emsf.getMaxLinearSpeed());
				mv = rectilinearMover;
				Post(new MouvementFinished(), mv.getDurationToReach());
			}

		}
	}


}
