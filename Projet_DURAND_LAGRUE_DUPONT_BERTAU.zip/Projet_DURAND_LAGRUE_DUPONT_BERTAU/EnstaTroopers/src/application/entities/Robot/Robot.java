package application.entities.Robot;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.vogella.algorithms.dijkstra.engine.DijkstraAlgorithm;
import de.vogella.algorithms.dijkstra.model.Graph;
import de.vogella.algorithms.dijkstra.model.IEdge;
import de.vogella.algorithms.dijkstra.model.IVertex;
import de.vogella.algorithms.dijkstra.model.jfxmodel.Point3DEdge;
import de.vogella.algorithms.dijkstra.model.jfxmodel.Point3DVertex;
import enstabretagne.base.logger.Logger;
import enstabretagne.monitor.interfaces.IMovable;
import enstabretagne.simulation.components.IEntity;
import enstabretagne.simulation.components.data.SimFeatures;
import enstabretagne.simulation.components.data.SimInitParameters;
import enstabretagne.simulation.components.implementation.SimEntity;
import enstabretagne.simulation.core.ISimObject;
import application.expertise.BorderAndPathGenerator;
import application.entities.MouvementSequenceur.EntityMouvementSequenceur;
import application.entities.MouvementSequenceur.EntityMouvementSequenceurExemple;
import application.entities.Robot.Representation3D.IRobot3D;
import application.entities.Wall.Wall;
import javafx.geometry.Bounds;
import javafx.geometry.Point3D;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.transform.Rotate;

public class Robot extends SimEntity implements IMovable, IRobot3D {
	RobotInit rIni;
	RobotFeatures rFeat;
	Point3D maPosition;
	private List<IVertex> nodes;
	private List<IEdge> edges;

	private EntityMouvementSequenceur rmv;

	Point3D dir;// direction du mouvement
	double speed;
	Rotate r;

	@Override
	public Point3D getPosition() {
		return rmv.getPosition(getCurrentLogicalDate());
	}

	@Override
	public Point3D getVitesse() {
		return rmv.getVitesse(getCurrentLogicalDate());
	}

	@Override
	public Point3D getAcceleration() {
		return rmv.getAcceleration(getCurrentLogicalDate());
	}

	@Override
	public Point3D getRotationXYZ() {
		return rmv.getRotationXYZ(getCurrentLogicalDate());
	}

	@Override
	public Point3D getVitesseRotationXYZ() {
		return rmv.getVitesseRotationXYZ(getCurrentLogicalDate());
	}

	@Override
	public Point3D getAccelerationRotationXYZ() {
		return rmv.getAccelerationRotationXYZ(getCurrentLogicalDate());
	}

	@Override
	public Color getColor() {
		return rIni.getCouleur();
	}

	@Override
	public double getSize() {
		return rFeat.getTaille();
	}

	@Override
	public int getType() {
		return 0;
	}

	@Override
	public boolean isBad() {
		return rIni.isBad();
	}

	public Robot(String name, SimFeatures features) {
		super(name, features);
		rFeat = (RobotFeatures) features;

		speed = rFeat.getVitesseMax();
		nodes = new ArrayList<IVertex>();
		edges = new ArrayList<IEdge>();
	}

	@Override
	protected void initializeSimEntity(SimInitParameters init) {
		rIni = (RobotInit) getInitParameters();
		maPosition = rIni.getPosInit();

		//le robot m�chant ne bouge pas
		if (rIni.isBad())
			rmv = (EntityMouvementSequenceur) createChild(EntityMouvementSequenceur.class, "Mvt", rFeat.getEmsf());
		
		//les robots gentils peuvent se d�placer en utilisant le SequenceurExemple
		else
			rmv = (EntityMouvementSequenceur) createChild(EntityMouvementSequenceurExemple.class, "Mvt",
					rFeat.getEmsf());
		rmv.initialize(rIni.getMvtSeqIni());
	}

	@Override
	protected void AfterActivate(IEntity sender, boolean starting) {
		Logger.Detail(this, "AfterActivate", "Activation du robot", "test");

		//seul le robot gentil cherche un autre robot et v�rifie s'il peut voir la table
		if (!isBad()) {
			List<ISimObject> l = getEngine().requestSimObject(simo -> (simo instanceof Robot) && (simo != this));
			for (ISimObject o : l)
				Logger.Information(this, "AfterActivate", "Robot trouve=" + o.getName());

			Logger.Information(this, "AfterActivate", "Can see table ? " + canSeeTable());
		}
		rmv.activate();
	}

	Cylinder lineOfSight;
	Cylinder lineOfSighthaut;
	Cylinder lineOfSightbas;
	Cylinder lineOfSightgauche;
	Cylinder lineOfSightdroite;

	public Cylinder getLineOfSight() {
		return lineOfSight;
	}
	public Cylinder getLineOfSighthaut() {
		return lineOfSighthaut;
	}
	public Cylinder getLineOfSightbas() {
		return lineOfSightbas;
	}
	public Cylinder getLineOfSightgauche() {
		return lineOfSightgauche;
	}
	public Cylinder getLineOfSightdroite() {
		return lineOfSightdroite;
	}

	//algorithme montrant un exemple pour trouver un objet pr�cis de la simulation et de v�rifier si on peut le voir
	//c'est � dire sans murs pour boucher la vue!

	private void addLane(Point3DVertex s, Point3DVertex t) {
		if(!nodes.contains(s)) nodes.add(s);
		if(!nodes.contains(t)) nodes.add(t);

		Point3DEdge e1 = new Point3DEdge(s,t);
		Point3DEdge e2 = new Point3DEdge(t,s);

		edges.add(e1);
		edges.add(e2);

	}

	public boolean canSeeTable() {
		
		//syntaxe complexe ci dessous: (List<Wall>) (List<?>) est une astuce pour caster les membres d'une liste
		//simo -> (xxxxx) est une lambda expression. C'est une mani�re tr�s compacte d'exprimer une functionnalinterface
		//au final on cherche uniquement des vrais murs (pas les objets de type table par exemple
		List<Wall> walls = (List<Wall>) (List<?>) getEngine()
				.requestSimObject(simo -> (simo instanceof Wall) && ((Wall) simo).getType() == 2);
		List<Bounds> bounds = new ArrayList();
		for (Wall w : walls) {
			bounds.addAll(w.getBounds());
		}

		//puis on cherche la table par son nom... c'est moche mais c'est pour l'exemple!
		Wall table = null;
		List<Wall> objets = (List<Wall>) (List<?>) getEngine().requestSimObject(simo -> (simo.getName() == "table"));
		if (objets.size() == 1) {
			table = objets.get(0);
			
			//on cr�e donc un cylindre entre les deux positions
			//on pourra afficher le cylindre dans la vue 3D
			lineOfSight = BorderAndPathGenerator.generateCylinderBetween(table.getPosition(), getPosition());
			lineOfSight.setMaterial(new PhongMaterial(Color.AQUA));

			//on v�rifie qu'on voit ou non la position de la table			
			boolean isVisible = BorderAndPathGenerator.intervisibilityBetween(table.getPosition(), getPosition(),
					bounds);
			return isVisible;
		} else
			return false;

	}

	public Point3D ping(){
		List<Point3D> list =new ArrayList<>();
		//syntaxe complexe ci dessous: (List<Wall>) (List<?>) est une astuce pour caster les membres d'une liste
		//simo -> (xxxxx) est une lambda expression. C'est une mani�re tr�s compacte d'exprimer une functionnalinterface
		//au final on cherche uniquement des vrais murs (pas les objets de type table par exemple
		List<Wall> walls = (List<Wall>) (List<?>) getEngine()
				.requestSimObject(simo -> (simo instanceof Wall) && ((Wall) simo).getType() >= 2);
		List<Bounds> bounds = new ArrayList();
		for (Wall w : walls) {
			bounds.addAll(w.getBounds());
		}

		Point3D pointhaut = new Point3D(this.getPosition().getX()-5,this.getPosition().getY(),this.getPosition().getZ());
		Point3D pointbas = new Point3D(this.getPosition().getX()+5,this.getPosition().getY(),this.getPosition().getZ());
		Point3D pointdroite = new Point3D(this.getPosition().getX(),this.getPosition().getY()+5,this.getPosition().getZ());
		Point3D pointgauche = new Point3D(this.getPosition().getX(),this.getPosition().getY()-5,this.getPosition().getZ());

		if(BorderAndPathGenerator.intervisibilityBetween(pointbas, getPosition(), bounds)){
			list.add(pointbas);
			addLane(new Point3DVertex(pointbas.getX(),pointbas.getY(),pointbas.getZ()),new Point3DVertex(this.getPosition().getX(),this.getPosition().getY(),this.getPosition().getZ()));
		}
		if(BorderAndPathGenerator.intervisibilityBetween(pointhaut, getPosition(), bounds)){
			list.add(pointhaut);
			addLane(new Point3DVertex(pointhaut.getX(),pointhaut.getY(),pointhaut.getZ()),new Point3DVertex(this.getPosition().getX(),this.getPosition().getY(),this.getPosition().getZ()));
		}
		if(BorderAndPathGenerator.intervisibilityBetween(pointdroite, getPosition(), bounds)){
			list.add(pointdroite);
			addLane(new Point3DVertex(pointdroite.getX(),pointdroite.getY(),pointdroite.getZ()),new Point3DVertex(this.getPosition().getX(),this.getPosition().getY(),this.getPosition().getZ()));
		}
		if(BorderAndPathGenerator.intervisibilityBetween(pointgauche, getPosition(), bounds)){
			list.add(pointgauche);
			addLane(new Point3DVertex(pointgauche.getX(),pointgauche.getY(),pointgauche.getZ()),new Point3DVertex(this.getPosition().getX(),this.getPosition().getY(),this.getPosition().getZ()));
		}

		

		Random rand = new Random();
		int choix = rand.nextInt( list.size()) ;

		//on cr�e donc un cylindre entre les deux positions
		//on pourra afficher le cylindre dans la vue 3D

		return list.get(choix);
	}

	public boolean canSeeRobot() {

		//syntaxe complexe ci dessous: (List<Wall>) (List<?>) est une astuce pour caster les membres d'une liste
		//simo -> (xxxxx) est une lambda expression. C'est une mani�re tr�s compacte d'exprimer une functionnalinterface
		//au final on cherche uniquement des vrais murs (pas les objets de type table par exemple
		List<Robot> robots = (List<Robot>) (List<?>) getEngine()
				.requestSimObject(simo -> (simo instanceof Robot) && ((Robot) simo).getType() == 3);


		//puis on cherche la table par son nom... c'est moche mais c'est pour l'exemple!
		Robot badguy = null;
		List<Robot> objets = (List<Robot>) (List<?>) getEngine().requestSimObject(simo -> (simo.getName() == "Grivious"));
		if (objets.size() == 1) {
			badguy = objets.get(0);


			if (badguy.getPosition().distance(this.getPosition()) < 10) {
				return true;
			} else
				return false;
		}
		return false;
	}


	public Point3D dijkstra() {
		// Lets check from location Loc_1 to Loc_10
		int x = 0;
		int y = 0;
		int z = 0;
		Graph graph = new Graph(nodes, edges);
		DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
		dijkstra.execute(new Point3DVertex(2,2,1));
		LinkedList<IVertex> path = dijkstra.getPath(new Point3DVertex(this.getPosition().getX(),this.getPosition().getY(),this.getPosition().getZ()));

		IVertex nextpoint = path.get(path.size() - 2);
		System.out.println(nextpoint.toString());

		Pattern p = Pattern.compile("x = (\\d+)[.]\\d, y = (\\d+)[.]\\d, z = (\\d+)[.]\\d");
		Matcher m = p.matcher(nextpoint.toString());
		while(m.find()) {
			x = Integer.parseInt(m.group(1));
			y = Integer.parseInt(m.group(2));
			z = Integer.parseInt(m.group(3));

		}
		return new Point3D(x,y,z);
	}

	@Override
	protected void BeforeDeactivating(IEntity sender, boolean starting) {
		rmv.deactivate();
	}

	@Override
	protected void BeforeActivating(IEntity sender, boolean starting) {

	}

	@Override
	protected void AfterDeactivated(IEntity sender, boolean starting) {

	}

	@Override
	protected void AfterTerminated(IEntity sender, boolean restart) {
	}

	@Override
	public void onParentSet() {

	}

}
