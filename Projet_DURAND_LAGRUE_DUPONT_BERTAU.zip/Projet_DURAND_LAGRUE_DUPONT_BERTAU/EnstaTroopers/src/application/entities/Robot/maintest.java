package application.entities.Robot;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class maintest {
    public static void main(String[] args) {
        // String to be scanned to find the pattern.
        Pattern p = Pattern.compile("x = (\\d+)[.]\\d, y = (\\d+)[.]\\d, z = (\\d+)[.]\\d");
        Matcher m = p.matcher("Point3D [x = 17.0, y = 27.0, z = 1.0]");
        while(m.find()) {
            System.out.println(m.group(1));
            System.out.println(m.group(2));
            System.out.println(m.group(3));
        }

    }
}
