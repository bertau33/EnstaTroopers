package application.entities.Robot;

import java.util.List;

import enstabretagne.simulation.components.data.SimFeatures;
import application.entities.MouvementSequenceur.EntityMouvementSequenceurFeature;

public class RobotFeatures extends SimFeatures{

	private double vitesseMax;
	private double accelerationMax;
	private double rotationSpeedMax;
	private double taille;
	private double autonomie ;
	private double vie;
		
	private EntityMouvementSequenceurFeature emsf;
	public EntityMouvementSequenceurFeature getEmsf() {
		return emsf;
	}
	
	public double getVitesseMax() {
		return vitesseMax;
	}
	public double getRotationSpeedMax() {
		return rotationSpeedMax;
	}
	public double getTaille() {
		return taille;
	}
	public double getAutonomie() { return autonomie; }
	public double getVie() { return vie; }

	public RobotFeatures(String id,
						 double vitesseMax,
						 double rotationSpeedMax,
						 double taille,
						 double autonomie,
						 double vie)
	{
		
		super(id);
		this.vitesseMax = vitesseMax;
		this.rotationSpeedMax = rotationSpeedMax;
		this.taille = taille;
		this.autonomie=autonomie;
		this.vie=vie;
		
		this.emsf = new EntityMouvementSequenceurFeature(
				"Sequenceur",
				vitesseMax,
				rotationSpeedMax);
				
	}
	
	
	
}
