package application.entities.Wall.Representation3D;

import java.util.List;

import enstabretagne.monitor.Contrat3D;
import enstabretagne.monitor.ObjTo3DMappingSettings;
import enstabretagne.monitor.implementation.Representation3D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.DrawMode;
import javafx.scene.shape.Shape3D;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;

@Contrat3D(contrat = IWall3D.class)
public class WallRepresentation3D extends Representation3D{

	IWall3D wall3D;
	Group monMur;


	public WallRepresentation3D(ObjTo3DMappingSettings settings) {
		super(settings);
	}

	@Override
	public void init(Group world, Object obj) {
		wall3D = (IWall3D) obj;
		monMur = new Group();

		PhongMaterial material;
		material = new PhongMaterial(wall3D.getColor());

		List<Node> murs = wall3D.getMurs();

		int type = wall3D.getType();

		switch (type) {
			case 1: //SOL
				Rectangle rg = new Rectangle(wall3D.getWidth(),wall3D.getHeight());
				rg.setFill(wall3D.getColor());
				monMur.getChildren().add(rg);
				break;

			case 2: //MUR
				for(Node b:murs) {
					if(b instanceof Shape3D)
						((Shape3D) b).setMaterial(material);
					((Shape3D) b).setDrawMode(DrawMode.FILL);
					monMur.getChildren().add(b);
				}
				break;
			case 3: //OBSTACLE
				Cylinder c1 = new Cylinder(wall3D.getWidth()/10,wall3D.getHeight());
				Cylinder c2 = new Cylinder(wall3D.getWidth()/10,wall3D.getHeight());
				Cylinder c3 = new Cylinder(wall3D.getWidth()/10,wall3D.getHeight());
				Cylinder c4 = new Cylinder(wall3D.getWidth()/10,wall3D.getHeight());
				Cylinder c5 = new Cylinder(wall3D.getWidth()*0.87,0.02);
				c1.setMaterial(material);
				c2.setMaterial(material);
				c3.setMaterial(material);
				c4.setMaterial(material);
				c5.setMaterial(material);
				c1.setRotationAxis(Rotate.X_AXIS);
				c1.setRotate(90);
				c2.setRotationAxis(Rotate.X_AXIS);
				c2.setRotate(90);
				c3.setRotationAxis(Rotate.X_AXIS);
				c3.setRotate(90);
				c4.setRotationAxis(Rotate.X_AXIS);
				c4.setRotate(90);
				c5.setRotationAxis(Rotate.X_AXIS);
				c5.setRotate(90);
				c1.setTranslateX(-wall3D.getWidth()/2);
				c2.setTranslateX(wall3D.getWidth()/2);
				c3.setTranslateX(wall3D.getWidth()/2);
				c4.setTranslateX(-wall3D.getWidth()/2);
				c1.setTranslateY(-wall3D.getWidth()/2);
				c2.setTranslateY(-wall3D.getWidth()/2);
				c3.setTranslateY(wall3D.getWidth()/2);
				c4.setTranslateY(wall3D.getWidth()/2);
				c1.setTranslateZ(wall3D.getHeight()/2);
				c2.setTranslateZ(wall3D.getHeight()/2);
				c3.setTranslateZ(wall3D.getHeight()/2);
				c4.setTranslateZ(wall3D.getHeight()/2);
				c5.setTranslateZ(wall3D.getHeight());
				monMur.getChildren().add(c1);
				monMur.getChildren().add(c2);
				monMur.getChildren().add(c3);
				monMur.getChildren().add(c4);
				monMur.getChildren().add(c5);
				monMur.setTranslateX(wall3D.getPosition().getX());
				monMur.setTranslateY(wall3D.getPosition().getY());
				break;
		}

		world.getChildren().add(monMur);
	}

	@Override
	public void update() {


	}



}